# taskMaster

Lab01
This is the very beginning of taskMaster App with three pages
   
![image1](/screenshots/myTasksPage01.png)
![image1](/screenshots/allTasksPage03.png)
![image1](/screenshots/addTaskPage02.png)



lab02
The app now has 2 new pages
Setting page to let the user enter his name
Task Detail page that has the task title and task description

![image](/screenshots/MainActivityWithNewRequirementLab02.png)
![image](/screenshots/TaskTitlePageFromButton1.png)
![image](/screenshots/TaskTitlePageFromButton2.png)
![image](/screenshots/TaskTitlePageFromButton3.png)
![image](/screenshots/SettingPage.png)
![image](/screenshots/TestSettingPage.png)